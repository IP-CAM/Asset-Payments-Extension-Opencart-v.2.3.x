<?php
// Text
$_['text_title'] = 'Оплатить картой Visa/MasterCard (AssetPayments)';
