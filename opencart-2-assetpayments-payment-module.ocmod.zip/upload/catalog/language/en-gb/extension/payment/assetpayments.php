<?php
// Text
$_['text_title'] = 'Pay by card Visa/MasterCard (AssetPayments)';
